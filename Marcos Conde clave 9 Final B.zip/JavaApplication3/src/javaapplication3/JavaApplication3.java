/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication3;

/**
 *
 * @author estudiante
 */
public class JavaApplication3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       String a = "en";
       int b = 1998;
       String c = "la vida era bella";
       int d = 2008;
       String e = "todo fue cambiando en un";
       double f = 0.32;
       String i = "asi es como todo comienza";
        System.out.println(a + b + c + d + e + f + i);
    }
    
}
